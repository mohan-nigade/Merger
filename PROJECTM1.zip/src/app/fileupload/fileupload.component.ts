import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { faCloudUploadAlt } from '@fortawesome/free-solid-svg-icons';
import { faFileAlt } from '@fortawesome/free-solid-svg-icons';
import * as XLSX from "xlsx";

@Component({
  selector: 'app-fileupload',
  templateUrl: './fileupload.component.html',
  styleUrls: ['./fileupload.component.css'],
})
export class FileuploadComponent implements OnInit {
  constructor() { }
  facloud = faCloudUploadAlt;
  fafile = faFileAlt;


  filename: any = '';
  fileList: any[] = [];
  @Output() onFileUpload: EventEmitter<any> = new EventEmitter<any>();
  ngOnInit(): void { }

  fileuploads(event: any) {

    let file = event.target.files[0];
    if (file) {
      this.filename = file.name;
      if (this.filename.length >= 12) {
        var splitName = this.filename.split('.');
        this.filename = splitName[0].substring(0, 20) + '... .' + splitName[1];
      }
    }
    this.fileList.push({
      id: this.fileList.length,
      name: this.filename,
      size: file.size,
    });

    ///conversion to JSON
    //console.log(event)
    const uploadedFilesData = {};
    const fileReader = new FileReader();
    fileReader.readAsBinaryString(file);
    fileReader.onload = (event: any) => {
      //console.log(event)
      let binaryData = event.target.result;
      let workbook = XLSX.read(binaryData, { type: "binary" });
      //console.log(workbook)
      workbook.SheetNames.forEach(sheet => {
        const data = XLSX.utils.sheet_to_json(workbook.Sheets[sheet]);
        // console.log(data);
        uploadedFilesData[sheet] = data;

      });
      this.onFileUpload.emit(uploadedFilesData);
    }
  }

  removeFile(id: number) {
    this.fileList = this.fileList.filter((file) => file.id !== id);
  }

}



