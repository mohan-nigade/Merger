import { Component, OnInit, Input } from '@angular/core';
import 'ag-grid-enterprise'
@Component({
  selector: 'app-ag-grid-table',
  templateUrl: './ag-grid-table.component.html',
  styleUrls: ['./ag-grid-table.component.scss']
})
export class AgGridTableComponent implements OnInit {
  gridApi: any;
  button = true
  @Input() set agGridData(value: any) {
    if (value == null) {
      return
    }
    this.rowData = value;
    this.showData()
  }
  rowData: any;

  columnDefs: any[] = []

  NoDataImg = 'assets/images/nodata2.png';

  constructor() { }


  ngOnInit(): void {

  }

  showData() {
    const colDefs = {}
    this.rowData.forEach(dataItem => {
      if (dataItem == null) {
        return;
      }
      Object.keys(dataItem).forEach(key => {
        if (colDefs[key] == null) {
          colDefs[key] = {
            field: key, sortable: true, filter: true, editable: true,
            floatingFilter: true
          }
          this.button = false
        }
      })
    })

    this.columnDefs = Object.values(colDefs)


  }

  onGridReady = (params) => {
    this.gridApi = params.api
  }

  onExportClick = () => {
    var excelParams = { fileName: `merged-${new Date().getMonth() + 1}${new Date().getDate()}${new Date().getFullYear()}`}
 this.gridApi.exportDataAsExcel(excelParams); }



}
