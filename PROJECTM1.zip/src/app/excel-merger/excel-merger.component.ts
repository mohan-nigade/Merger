import { Component, OnInit } from '@angular/core';
import { ItemsSelectorComponent } from '../items-selector/items-selector.component'
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-excel-merger',
  templateUrl: './excel-merger.component.html',
  styleUrls: ['./excel-merger.component.scss']
})
export class ExcelMergerComponent implements OnInit {

  convertedData: any = []

  logoImg = 'assets/images/logo.png';

  constructor(public dialog: MatDialog) { }

  ngOnInit(): void {

  }

  fileuploads(dataValue: any) {
    if (dataValue == null) {
      return
    }

    const dialogRef = this.dialog.open(ItemsSelectorComponent, {

      width: '100vh',
      data: dataValue,

    });
    dialogRef.afterClosed().subscribe((result) => {

      this.convertedData = result.concat(this.convertedData)
    });
  }

}
