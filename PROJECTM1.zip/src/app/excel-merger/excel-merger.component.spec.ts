import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ExcelMergerComponent } from './excel-merger.component';

describe('ExcelMergerComponent', () => {
  let component: ExcelMergerComponent;
  let fixture: ComponentFixture<ExcelMergerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ExcelMergerComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ExcelMergerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
