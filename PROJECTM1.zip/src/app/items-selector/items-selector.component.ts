import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';


@Component({
  selector: 'app-items-selector',
  templateUrl: './items-selector.component.html',
  styleUrls: ['./items-selector.component.scss']
})
export class ItemsSelectorComponent implements OnInit {
  allInnerKeys: string[] = [];
  checkedValues: any[] = [];
  primaryKey: string; // new property to store the selected primary key
  constructor(@Inject(MAT_DIALOG_DATA) public data: any, private Ref: MatDialogRef<ItemsSelectorComponent>) { }
  result: any;

  ngOnInit(): void {
    this.result = this.data
    for (const obj of Object.values(this.result)) {
      obj[0].parentChecked = false;
    }


    const allObjects = Object.values(this.result).flat(); // get an array of all objects across all properties
    const allKeys = allObjects.flatMap(obj => Object.keys(obj)); // get an array of all keys across all objects
    this.allInnerKeys = Array.from(new Set(allKeys.filter(key => key !== 'parentChecked'))); // remove duplicates
  }

  onOkClicked() {
console.log(this.result)
    if (this.primaryKey) {
      this.checkedValues = [];

      // Step 1: Collect the checked values into checkedValues array
      for (const [key, value] of Object.entries(this.result)) {
        if (value[0].parentChecked) {
          const obj = { [key]: {} };
          for (const [innerKey, innerValue] of Object.entries(value[0])) {
            if (innerKey !== 'parentChecked' && value[0].parentChecked && innerValue) {
              obj[key][innerKey] = innerValue;
            }
          }
          if (Object.keys(obj[key]).length > 0) {
            this.checkedValues.push(obj);
          }
        }
      }

      // Step 2: Extract matching inner key-value pairs and put them in newValues array

      const newValues = [];
      for (const checkedValue of this.checkedValues) {
        const checkedOuterKey = Object.keys(checkedValue)[0];
        const checkedInnerKeys = Object.keys(checkedValue[checkedOuterKey]);
        for (const resultValue of this.result[checkedOuterKey]) {
          const newObj = {};
          for (const checkedInnerKey of checkedInnerKeys) {
            if (checkedInnerKey in resultValue) {
              newObj[checkedInnerKey] = resultValue[checkedInnerKey];
            }
          }
          if (Object.keys(newObj).length > 0) {
            // Check if there is already an object in newValues array with the same value for primaryKey key as newObj
            const existingObjIndex = newValues.findIndex(obj => obj[this.primaryKey] === newObj[this.primaryKey]);
            if (existingObjIndex !== -1) {
              // If an object is found, then update the existing object with the union of newObj and existing object
              const existingObj = newValues[existingObjIndex];
              newValues[existingObjIndex] = { ...existingObj, ...newObj };
            } else {
              // If no object is found, then push newObj to newValues array
              newValues.push(newObj);
            }
          }
        }
      }


      // Step 3: Close the dialog and pass the newValues array to the parent component

      this.Ref.close(this.getDistinctObjectsByKey(newValues, this.primaryKey));
    } else {
      this.checkedValues = [];
  
    // Step 1: Collect the checked values into checkedValues array
    for (const [key, value] of Object.entries(this.result)) {
      if (value[0].parentChecked) {
        const obj = { [key]: {} };
        for (const [innerKey, innerValue] of Object.entries(value[0])) {
          if (innerKey !== 'parentChecked' && value[0].parentChecked && innerValue) {
            obj[key][innerKey] = innerValue;
          }
        }
        if (Object.keys(obj[key]).length > 0) {
          this.checkedValues.push(obj);
        }
      }
    }
  
    // Step 2: Extract matching inner key-value pairs and put them in newValues array
    const newValues = [];
    for (const checkedValue of this.checkedValues) {
      const checkedOuterKey = Object.keys(checkedValue)[0];
      const checkedInnerKeys = Object.keys(checkedValue[checkedOuterKey]);
      for (const resultValue of this.result[checkedOuterKey]) {
        const newObj = {};
        for (const checkedInnerKey of checkedInnerKeys) {
          if (checkedInnerKey in resultValue) {
            newObj[checkedInnerKey] = resultValue[checkedInnerKey];
          }
        }
        if (Object.keys(newObj).length > 0) {
          newValues.push(newObj);
        }
      }
    }
  
    // Step 3: Close the dialog and pass the newValues array to the parent component
    this.Ref.close(newValues);
    }


  }

  getDistinctObjectsByKey(objects: any[], key: string): any[] {
    const distinctValues = Array.from(new Set(objects.map(obj => obj[key])));
    const distinctObjects = {};
    for (const value of distinctValues) {
      distinctObjects[value] = {};
      for (const obj of objects) {
        if (obj[key] === value) {
          distinctObjects[value] = { ...distinctObjects[value], ...obj };
        }
      }
    }
    return Object.values(distinctObjects);
  }

  /*end*/
  

}

